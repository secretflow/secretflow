# Author: Wang Yao <wangyao@tsingj.com>.

"""Protocol

node process transaction steps:

    1. *node* receives any Package, transaction starts
    2. *node* will wait for data transmission according to transaction's Package.operation (with timeout RECV_TIMEOUT)
    3. *node* receives data, and waits for Package.total packages to be received (with timeout RECV_TIMEOUT)
    4. *node* begins to re-dispatch data according to self-description information (with timeout DISPATCH_TIMEOUT)
    5. (if necessary) *node* begins to send data to the next node (with timeout SEND_TIMEOUT)
    6. All steps above are successful, the current node transaction ends

note:

    * All *nodes* will repeatedly repeat the above steps
    * *node* is only responsible for verification/distribution, and the distribution operation is **completely determined by the self-description information**, that is, the user decides
    * Any error in the transaction will be abandoned by the current node, and Error will be broadcast to (in the current transaction) all nodes
    * Any *node* receives Error information will immediately abandon the corresponding transaction

"""

import json
import math
from abc import abstractmethod
from enum import Enum
from typing import Any, Dict, Generator, Optional, Union

from google.protobuf.json_format import MessageToDict
from pydantic import BaseModel, Field, root_validator, validator

from .anyconn_pb2 import (
    MSG as pb_MSG,
    Error as pb_Error,
    Package as pb_Package,
    Ping as pb_Ping,
)
from .utils import gen_md5_sign


class ErrorCode(str, Enum):
    SERVER_ERROR = "SERVER_ERROR"
    """server error, node cannot continue to provide services"""

    RECV_FAIL = "RECV_FAIL"  # todo remove: unused
    """receive failed"""

    SEND_FAIL = "SEND_FAIL"
    """send failed"""

    DISPATCH_FAIL = "DISPATCH_FAIL"
    """dispatch failed"""

    CHANNEL_TIMEOUT = "CHANNEL_TIMEOUT"
    """channel timeout"""

    RECV_TIMEOUT = "RECV_TIMEOUT"
    """receive timeout"""

    DISPATCH_TIMEOUT = "DISPATCH_TIMEOUT"
    """dispatch timeout"""

    SEND_TIMEOUT = "SEND_TIMEOUT"
    """send timeout"""


class MSG(BaseModel):
    cid: str = Field(...)
    """transaction ID"""

    ttl: int = Field(0)
    """ttl"""

    @abstractmethod
    def parse_pb_MSG(cls, msg: pb_MSG) -> "MSG":  # noqa
        ...

    @abstractmethod
    def to_pb_MSG(self) -> "pb_MSG":
        ...


class Error(MSG):
    """error message"""

    code: ErrorCode = Field(...)
    """error code"""

    detail: str = Field(...)
    """error detail"""

    @classmethod
    def parse_pb_MSG(cls, msg: pb_MSG) -> "Error":
        """initialize by a protos.MSG object"""
        return cls(
            cid=msg.cid,
            ttl=msg.ttl,
            **MessageToDict(msg.error, including_default_value_fields=True),
        )

    def to_pb_MSG(self) -> pb_MSG:
        """convert to a protos.MSG object"""
        return pb_MSG(
            cid=self.cid,
            ttl=self.ttl,
            error=pb_Error(code=self.code, detail=self.detail),
        )

    def __repr__(self) -> str:
        return f"Error(cid={self.cid}, code={self.code}, detail={self.detail})"


class Package(MSG):
    """Package, the basic unit of node communication, each package contains complete transaction self-description information"""

    operation: int = Field(1, ge=1)
    """operation number (in this transmission transaction)"""

    seq: int = Field(..., ge=1)
    """package sequence number, start from 1"""

    total: int = Field(..., ge=1)
    """total package number"""

    detail: Dict[str, Any] = Field({})
    """detail information, the structure is determined by the user"""

    data: bytes = Field(b"")
    """data"""

    sign: bytes = Field(b"")
    """signature"""

    node_id: Optional[str] = Field(None)
    """node ID, the node that sends/receives the package"""

    @property
    def is_ready(self) -> bool:
        """ready or not"""
        return self.node_id is not None

    def set_ready(self, node_id: str) -> "Package":
        """set ready"""
        self.node_id = node_id
        return self

    @classmethod
    def parse_pb_MSG(cls, pb_msg: pb_MSG) -> "Package":
        """initialize by a protos.MSG object"""
        pack: Package = cls(
            cid=pb_msg.cid,
            ttl=pb_msg.ttl,
            operation=pb_msg.package.operation,
            seq=pb_msg.package.seq,
            total=pb_msg.package.total,
            detail=pb_msg.package.detail,
            data=pb_msg.package.data,
        )
        if pb_msg.package.sign != pack.sign:
            raise ValueError(f"Signature error, package: [cid:{pack.cid}] [seq:{pack.seq}]")
        return pack

    def to_pb_MSG(self) -> pb_MSG:
        """convert to a protos.MSG object"""
        return pb_MSG(
            cid=self.cid,
            ttl=self.ttl,
            package=pb_Package(
                **self.dict(exclude={"node_id", "cid", "ttl", "detail"}),
                detail=json.dumps(self.detail),
            ),
        )

    @validator("detail", pre=True)
    def __detail(cls, v: Union[str, Dict]) -> Dict[str, Any]:  # noqa
        """convert detail to dict

        todo refactor: if the structure of the detail field can be determined, consider removing JSON serialization
        """
        return json.loads(v) if isinstance(v, str) else v

    @root_validator(pre=False, skip_on_failure=True)
    def __root(cls, values: Dict) -> Dict:  # noqa
        # check seq
        if values["seq"] > values["total"]:
            raise ValueError(f"seq `{values['seq']}` can not bigger than total `{values['total']}`")
        # check signature
        if not values["sign"]:
            values["sign"] = gen_md5_sign(
                values["cid"].encode("utf-8"),
                str(values["seq"]).encode("utf-8"),
                values["data"],
            )
        return values

    @classmethod
    def make_packages(
        cls,
        cid: str,
        package_size: int,
        node_id: str,
        data: bytes,
        operation: int,
        detail: Optional[Dict[str, Any]] = None,
    ) -> Generator["Package", None, None]:
        """Batch generate Packages"""

        def _make():
            total = math.ceil(len(data) / package_size)
            for i in range(total):
                yield cls(
                    cid=cid,
                    operation=operation,
                    seq=i + 1,
                    total=total,
                    node_id=node_id,
                    detail=detail or {},
                    data=data[i * package_size : (i + 1) * package_size],
                )

        return _make()

    def __eq__(self, other) -> bool:
        return self.sign == other.sign

    def __hash__(self) -> int:
        return hash(self.sign)


class Ping(MSG):
    """Used to check whether the node is alive"""

    def to_pb_MSG(self) -> pb_MSG:
        """Convert to a protos.MSG object"""
        return pb_MSG(cid=self.cid, ttl=self.ttl, ping=pb_Ping())

    @classmethod
    def parse_pb_MSG(cls, msg: pb_MSG) -> "Ping":
        """Initialize by a protos.MSG object"""
        return cls.parse_obj({"cid": msg.cid, "ttl": msg.ttl + 1})
