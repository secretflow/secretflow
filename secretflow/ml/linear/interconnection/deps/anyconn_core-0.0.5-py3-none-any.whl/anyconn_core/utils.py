# Author: Wang Yao <wangyao@tsingj.com>.

from hashlib import md5


def gen_md5_sign(*args: bytes) -> bytes:
    md = md5()
    for i in args:
        md.update(i)
    return md.digest()
