# Author: Wang Yao <wangyao@tsingj.com>.

from typing import Any, Awaitable, Callable

from tiny_listener import Event

from .protocol import Error


def scope(name: str) -> Callable[..., Awaitable[Any]]:
    """get scope data from event

    :param name: scope name
    """

    async def fn(event: Event):
        return event.ctx.scope[name]

    return fn


async def get_error(event: Event) -> Error:
    """get error from event"""
    return Error(
        cid=event.ctx.cid,
        code=event.params.get("code"),
        detail=event.params.get("detail"),
    )
