# Author: Wang Yao <wangyao@tsingj.com>.

from enum import Enum
from operator import attrgetter
from typing import Any, Dict, Iterator, Optional, Set

from .protocol import Package


class PackageNotReady(Exception):
    pass


class OperationNotFound(Exception):
    pass


class TransactionNotReady(Exception):
    pass


class TransactionStage(str, Enum):
    """transaction stage"""

    RECEIVING = "RECEIVING"
    """sending stage"""

    DISPATCHING = "DISPATCHING"
    """dispatching stage"""

    SENDING = "SENDING"
    """sending stage"""

    OK = "OK"
    """ok stage"""

    ERROR = "ERROR"
    """error stage"""


class Operation:
    """

    :param node_id: node ID for this operation
    :param expected: expected package count
    :param detail: detail
    """

    def __init__(self, node_id: str, expected: int, detail: Dict[str, Any]) -> None:
        self.__packages: Set[Package] = set()
        self.__node_id = node_id
        self.__expected = expected
        self.__is_done: bool = False
        self.detail = detail

    @property
    def node_id(self) -> str:
        return self.__node_id

    @property
    def packages(self) -> Set["Package"]:
        """(received) packages"""
        return self.__packages

    @property
    def expected(self) -> int:
        """expected package count"""
        return self.__expected

    @property
    def actual(self) -> int:
        """实际收到包数量"""
        return len(self.__packages)

    @property
    def is_done(self) -> bool:
        """is all packages received"""
        return self.__is_done

    def commit(self, pack: "Package"):
        """commit a package

        :param pack: package
        :raises: PackageNotReady
        """
        if not pack.is_ready:
            raise PackageNotReady(f"Package not Ready: `{pack.cid}`")

        self.__packages.add(pack)
        if self.expected == self.actual:
            self.__is_done = True

    def __iter__(self) -> Iterator["Package"]:
        """iter packages"""
        return iter(self.__is_done and sorted(self.__packages, key=attrgetter("seq")) or [])

    def data(self) -> bytes:
        """data of all packages"""
        return b"".join([i.data for i in self])

    def __repr__(self) -> str:
        return f"Operation(is_done={self.__is_done}, packages: {self.actual}/{self.expected})"


class Transaction:
    """
    :param stage: transaction stage
    :param deadline: transaction deadline
    """

    def __init__(self, deadline: float, stage: TransactionStage = TransactionStage.RECEIVING) -> None:
        self.deadline = deadline
        self.ops: Dict[str, Operation] = {}
        self.__stage = stage
        self.__rest: int = 0
        self.__is_ready: bool = False
        self.__is_done: bool = False
        self.__op_count: Optional[int] = None
        self.cid: Optional[str] = None

    @property
    def op_count(self) -> int:
        """operation count"""
        return self.__op_count

    @property
    def is_ready(self) -> bool:
        """is transaction ready"""
        return self.__is_ready

    def __check_is_ready(self):
        if not self.__is_ready:
            raise TransactionNotReady("Transaction not ready")

    @property
    def stage(self) -> TransactionStage:
        return self.__stage

    @property
    def rest(self) -> int:
        """rest package count"""
        self.__check_is_ready()
        return self.__rest

    @rest.setter
    def rest(self, v: int) -> None:
        self.__rest = v

    @property
    def expected(self) -> int:
        """expected operation count"""
        self.__check_is_ready()
        return self.__op_count

    @property
    def actual(self) -> int:
        """the number of operations that have been completed"""
        self.__check_is_ready()
        return sum(1 for op in self.ops.values() if op.is_done)

    @property
    def is_done(self) -> int:
        """is all operations done"""
        self.__check_is_ready()
        return self.__is_done

    def get_operation(self, node_id: str) -> Operation:
        """get operation by node ID

        :param node_id: node ID
        """
        self.__check_is_ready()
        try:
            return self.ops[node_id]
        except KeyError as e:
            raise OperationNotFound("Operation not found") from e

    def commit(self, pack: "Package") -> None:
        """commit a package

        :param pack: package
        :raises: PackageNotReady
        """
        if not self.is_ready:
            self.cid = pack.cid
            self.__op_count = pack.operation
            self.__is_ready = True

        if pack.node_id not in self.ops:
            self.ops[pack.node_id] = Operation(node_id=pack.node_id, expected=pack.total, detail=pack.detail)

        self.ops[pack.node_id].commit(pack)
        if self.expected == self.actual:
            self.__is_done = True

    def set_stage(self, stage: TransactionStage) -> bool:
        """set transaction stage"""
        is_changed = stage is not self.__stage
        self.__stage = stage
        return is_changed

    def consume_one(self) -> bool:
        """consume one package

        if return True, all packages have been consumed
        """
        self.__rest -= 1
        return self.rest <= 0

    def __repr__(self) -> str:
        if not self.is_ready:
            return "Transaction(PREPARING)"
        if self.__stage is TransactionStage.SENDING:
            expected = sum(i.expected for i in self.ops.values())
            return f"Transaction(cid={self.cid}, stage={self.__stage}, packages: {expected - self.rest}/{expected}))"

        if self.__stage is TransactionStage.RECEIVING:
            return f"Transaction(cid={self.cid}, stage={self.__stage}, ops: {self.actual}/{self.expected})"

        return f"Transaction(cid={self.cid}, {self.__stage.value})"
