import sys

import click
from tiny_listener.utils import import_from_string

from anyconn_core import __version__


def show_version(ctx, _, value) -> None:
    if not value or ctx.resilient_parsing:
        return
    click.echo(f"anyconn-core {__version__}")
    ctx.exit()


@click.option(
    "--version",
    is_flag=True,
    callback=show_version,
    expose_value=False,
    is_eager=True,
    help="Display version info.",
)
@click.option("--app-dir", "app_dir", default=".", show_default=True, help="Your APP directory.")
@click.option("--conf-path", required=True, help="配置文件(.yaml)路径")
@click.command(help="run node")
@click.argument("app")
def main(app: str, app_dir, conf_path: str):
    sys.path.insert(0, app_dir)
    try:
        app = import_from_string(app)
    except Exception as e:
        click.echo(e)
        sys.exit(1)
    else:
        app.run_node(conf_path)


if __name__ == "__main__":
    main()
