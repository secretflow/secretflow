# Author: Wang Yao <wangyao@tsingj.com>.

import asyncio
import logging
import os
import traceback
from abc import ABCMeta, abstractmethod
from asyncio import StreamWriter
from operator import attrgetter
from typing import TYPE_CHECKING, List, Optional

import grpc
from grpc.aio import AioRpcError
from jinja2 import Environment, FileSystemLoader
from tiny_listener import ContextNotFound, Depends, Event

from .anyconn_pb2_grpc import RouterStub
from .channel import ChannelNotFound, ClientSideChannel, ServerSideChannel
from .dependant import get_error, scope
from .protocol import MSG, Error, ErrorCode, Package, Ping
from .transaction import PackageNotReady, Transaction, TransactionStage

if TYPE_CHECKING:
    from .application import Application

logger = logging.getLogger("anyconn")

StageTimeoutError = {
    TransactionStage.RECEIVING: ErrorCode.RECV_TIMEOUT,
    TransactionStage.DISPATCHING: ErrorCode.DISPATCH_TIMEOUT,
    TransactionStage.SENDING: ErrorCode.SEND_TIMEOUT,
}


class MessageIterator:
    """request message iterator

    :param app: Application
    :param grpc_ch: GRPC connection
    :param chan: request RS target
    """

    def __init__(self, app: "Application", grpc_ch: grpc.Channel, chan: ClientSideChannel):
        self.app = app
        self.chan = chan
        self.iter = RouterStub(grpc_ch).Main(
            self.gen_package(),
            metadata=[("node_id", chan.local_node.id)],
            wait_for_ready=True,
        )

    def __aiter__(self):
        return self.iter.__aiter__()

    async def gen_package(self):
        yield Ping(cid="").to_pb_MSG()
        self.chan.on()
        logger.info("[%s] %s", self.app, self.chan)

        while True:
            await self.chan.wait_on()
            msg = await self.chan.send_queue.get()
            ctx = self.app.ctxs.get(msg.cid)
            if ctx is None:
                continue

            try:
                yield msg.to_pb_MSG()
                if isinstance(msg, Package):
                    trans: Transaction = ctx.scope["trans"]
                    trans.deadline = self.app.send_timeout  # try to send package, block until timeout
                    logger.debug("[%s] %s", self.app, trans)
                    if trans.consume_one():
                        trans.set_stage(TransactionStage.OK)
                        logger.debug("[%s] %s", self.app, trans)
                        ctx.drop()
            except GeneratorExit as e:
                ctx.drop()
                logger.warning("[%s] Channel [%s] send package fail: %s", self.app, self.chan, e)
                break


class Handler(metaclass=ABCMeta):
    def __init__(self, app: "Application"):
        self.app = app

    @abstractmethod
    def install(self) -> None:
        ...


class TransHandler(Handler):
    def install(self) -> None:
        self._install_trans_raise()
        self._install_trans_timer()
        self._install_trans_dispatch()

    def _install_trans_dispatch(self):
        """install transaction dispatch handler"""

        @self.app.on_event("/trans/dispatch")
        async def trans_dispatch(event: Event, *, trans: Transaction = Depends(scope("trans"))):
            # end transaction
            ctx = event.ctx
            trans.set_stage(TransactionStage.OK)
            logger.debug("[%s] %s", self.app, trans)

            # end if no dispatch
            if self.app.dispatch_callback is None:
                ctx.drop()
                return

            # execute dispatch callback
            try:
                packs: Optional[List[Package]] = await self.app.execute(self.app.dispatch_callback, self.app.cfg, trans)  # type: ignore
            except Exception as e:
                ctx.trigger_event(f"/trans/raise/{ErrorCode.DISPATCH_FAIL}/Dispatch error: {e}")
                return

            # end transaction if no packs
            if not packs:
                trans.set_stage(TransactionStage.OK)
                ctx.drop()
                logger.debug("[%s] %s", self.app, trans)
                return

            # send all packages
            for pack in packs:
                try:
                    ctx = self.app.get_ctx(pack.cid)
                except ContextNotFound:
                    # context not found, create transaction and start timer
                    trans = Transaction(stage=TransactionStage.SENDING, deadline=self.app.send_timeout)
                    ctx = self.app.new_ctx(cid=pack.cid, scope={"trans": trans})
                    ctx.trigger_event("/trans/timer")
                    trans.rest = sum(1 for p in packs if p.cid == pack.cid)
                    logger.debug("[%s] Transaction(cid=%s, PREPARING)", self.app, ctx.cid)
                else:
                    trans: Transaction = ctx.scope["trans"]

                try:
                    chan = self.app.get_channel(node=pack.node_id)
                except ChannelNotFound as e:
                    ctx.trigger_event(f"/trans/raise/{ErrorCode.DISPATCH_FAIL}/Dispatch error: {e}")
                    break
                else:
                    pack.set_ready(chan.target_node.id)
                    trans.commit(pack)
                    await chan.send(pack)

    def _install_trans_raise(self) -> None:
        """install transaction error handler"""

        @self.app.on_event("/trans/raise/{code}/{detail}")
        async def trans_raise(
            event: Event,
            *,
            trans: Transaction = Depends(scope("trans")),
            error: Error = Depends(get_error),
        ):
            """broadcast error to all nodes"""
            trans.set_stage(TransactionStage.ERROR)
            event.ctx.drop()
            logger.debug("[%s] %s %s:%s", self.app, trans, error.code, error.detail)
            for node_id in trans.ops:
                await self.app.get_channel(node_id).send(error)

    def _install_trans_timer(self) -> None:
        """install transaction timer handler"""

        @self.app.on_event("/trans/timer")
        async def trans_timer(event: Event, *, trans: Transaction = Depends(scope("trans"))):
            """transaction timer

            a transaction need to handle all packages, error or timeout transaction will be abandoned
            """
            ctx = event.ctx
            while trans.deadline > 0:
                if (
                    trans.stage is TransactionStage.ERROR
                    or trans.stage is TransactionStage.OK
                    or ctx.cid not in self.app.ctxs
                ):
                    # transaction removed, end timer
                    return
                trans.deadline -= 5
                await asyncio.sleep(5)

            ctx.trigger_event(f"/trans/raise/{StageTimeoutError[trans.stage]}/Timeout error, stage: {trans.stage}")


class ChanHandler(Handler):
    def install(self) -> None:
        self._install_chan_connect()
        self._install_chan_recv()
        self._install_chan_send()

    def _install_chan_connect(self) -> None:
        """install channel connect handler"""

        @self.app.on_event("/chan/connect")
        async def chan_connect(*, chan: ClientSideChannel = Depends(scope("chan"))):
            """build connection with node"""
            async with grpc.aio.insecure_channel(chan.target_node.address) as grpc_ch:
                while True:
                    try:
                        async for pb_msg in MessageIterator(self.app, grpc_ch, chan):
                            _type = pb_msg.WhichOneof("payload")
                            if _type == "error":
                                err = Error.parse_pb_MSG(pb_msg)
                                logger.error("[%s] Transaction error [%s]", self.app, err)
                            elif _type == "package":
                                await chan.recv_queue.put(Package.parse_pb_MSG(pb_msg))
                    except AioRpcError as e:
                        chan.off()
                        logger.info("[%s] %s [%s %s]", self.app, chan, e.code(), e.details())
                    except Exception as e:
                        chan.off()
                        logger.info("[%s] %s [%s]", self.app, chan, e)
                        traceback.print_exc()
                    await asyncio.sleep(3)

    def _install_chan_recv(self) -> None:
        """install channel recv handler"""

        @self.app.on_event("/chan/recv")
        async def chan_recv(*, chan: ServerSideChannel = Depends(scope("chan"))):
            """receive channel data, channel will be alive after created"""
            while True:
                await chan.wait_on()
                pack: Package = await chan.recv()  # type: ignore
                try:
                    ctx = self.app.get_ctx(pack.cid)
                except ContextNotFound:
                    # context not found, create transaction and start timer
                    trans = Transaction(stage=TransactionStage.RECEIVING, deadline=self.app.recv_timeout)
                    ctx = self.app.new_ctx(cid=pack.cid, scope={"trans": trans})
                    ctx.trigger_event("/trans/timer")
                    logger.debug("[%s] Transaction(cid=%s, PREPARING)", self.app, ctx.cid)
                else:
                    trans: Transaction = ctx.scope["trans"]
                    trans.deadline = self.app.recv_timeout  # reset transaction timeout when any package received

                pack.set_ready(chan.target_node.id)
                trans.commit(pack)
                logger.debug("[%s] %s", self.app, trans)
                if trans.is_done:
                    logger.debug("[%s] Transaction(cid=%s, RECEIVING done)", self.app, ctx.cid)
                    # enter dispatch stage
                    trans.set_stage(TransactionStage.DISPATCHING)
                    trans.deadline = self.app.dispatch_timeout
                    ctx.trigger_event("/trans/dispatch")

    def _install_chan_send(self) -> None:
        """install channel send handler"""

        @self.app.on_event("/chan/send")
        async def chan_send(*, chan: ServerSideChannel = Depends(scope("chan"))):
            """send data to channel, channel will be alive after created"""
            while True:
                await chan.wait_on()
                msg: MSG = await chan.send_queue.get()
                # send error to node
                if isinstance(msg, Error):
                    try:
                        await chan.context.write(msg.to_pb_MSG())  # type: ignore
                    except Exception as e:
                        logger.warning("[%s] Channel [%s] send error fail: %s", self.app, chan, e)
                        traceback.print_exc()
                        continue

                # send package to node, todo: retry if necessary
                if isinstance(msg, Package):
                    ctx = self.app.ctxs.get(msg.cid)  # todo: refactor someday
                    if ctx is None:
                        continue

                    await chan.wait_on()
                    try:
                        if not msg.is_ready:
                            raise PackageNotReady(f"Package not ready: `{msg.cid}`")
                        await chan.context.write(msg.to_pb_MSG())  # type: ignore
                        trans: Transaction = ctx.scope["trans"]
                        trans.set_stage(TransactionStage.SENDING)
                        trans.deadline = self.app.send_timeout  # reset transaction timeout when any package sent
                        ok = trans.consume_one()
                        logger.debug("[%s] %s", self.app, trans)
                        if ok:
                            trans.set_stage(TransactionStage.OK)
                            logger.debug("[%s] %s", self.app, trans)
                            ctx.drop()
                    except PackageNotReady as e:
                        logger.error("[%s] Channel [%s] send package fail: %s", self.app, chan, e)
                        ctx.trigger_event(f"/trans/raise/{ErrorCode.SERVER_ERROR}/{repr(e)}")
                    except Exception as e:
                        logger.error("[%s] Channel [%s] send package fail: %s", self.app, chan, e)
                        traceback.print_exc()
                        ctx.trigger_event(f"/trans/raise/{ErrorCode.SEND_FAIL}/{repr(e)}")


ROOT = os.path.dirname(os.path.realpath(__file__))

TEMPLATE_ENV = Environment(loader=FileSystemLoader(searchpath=os.path.join(ROOT, "static")))


async def get_writer(event: Event):
    return event.data["writer"]


def render(name: str, *args, **kwargs) -> str:
    """render template

    :param name: template name, under TEMPLATE_ENV path
    """
    return TEMPLATE_ENV.get_template(name).render(*args, **kwargs)


class HTTPHandler(Handler):
    def install(self) -> None:
        self._install_http_home()
        self._install_http_static()
        self._install_http_404()
        self._install_http_remove_ctx()

    def _install_http_home(self) -> None:
        """HTTP API: home-page"""

        @self.app.on_event("/HTTP/GET/home")
        async def http_get_home(*, writer: StreamWriter = Depends(get_writer, use_cache=False)):
            channels = self.app.channels.values()
            send_qsize = sum([chan.send_queue.qsize() for chan in channels])
            recv_qsize = sum([chan.recv_queue.qsize() for chan in channels])
            transactions: List[Transaction] = []

            for ctx in self.app.ctxs.values():
                trans = ctx.scope.get("trans")
                if trans:
                    transactions.append(trans)
            html = render(
                "home.html",
                app=self.app,
                channels=sorted(channels, key=attrgetter("target_node.tag", "target_node.id")),
                send_qsize=send_qsize,
                recv_qsize=recv_qsize,
                transactions=transactions,
            )
            writer.write(f"HTTP/1.1 200\n\n{html}".encode())
            writer.close()

    def _install_http_remove_ctx(self) -> None:
        """HTTP API: remove context"""

        @self.app.on_event("/HTTP/GET/ctx/{ctx_id}")
        async def http_get_ctx(
            event: Event,
            *,
            writer: StreamWriter = Depends(get_writer, use_cache=False),
        ):
            """remove a context"""
            ctx = self.app.ctxs.get(event.params["ctx_id"])
            if ctx:
                ctx.drop()
            writer.write(b"HTTP/1.1 301\nLocation: /home\n\n")
            writer.close()

    def _install_http_static(self) -> None:
        """HTTP API: static file"""

        @self.app.on_event("/HTTP/GET/static/{file:str}")
        async def http_get_static(
            event: Event,
            *,
            writer: StreamWriter = Depends(get_writer, use_cache=False),
        ):
            with open(f"{ROOT}/static/{event.params['file']}", "rb") as f:
                writer.write(b"HTTP/1.1 200\n\n" + f.read())
                writer.close()

    def _install_http_404(self) -> None:
        """HTTP API: 404"""

        @self.app.on_event("/HTTP/{_:path}")
        async def http_404(*, writer: StreamWriter = Depends(get_writer, use_cache=False)):
            writer.write(f"HTTP/1.1 404\n\n{render('404.html')}".encode())
            writer.close()
