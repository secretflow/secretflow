# Author: Wang Yao <wangyao@tsingj.com>.

"""Channel is the basic communication unit of Anyconn.
"""

import asyncio
from abc import ABCMeta, abstractmethod
from typing import TYPE_CHECKING, Optional

import grpc
from pydantic import BaseModel, Field, validator

if TYPE_CHECKING:
    from .protocol import MSG


class NodeNotFound(Exception):
    pass


class ChannelNotFound(Exception):
    pass


class Node(BaseModel):
    id: str = Field(...)
    """node ID"""
    tag: str = Field(...)
    """node tag"""
    address: str = Field(...)
    """node address"""

    @property
    def port(self) -> int:
        *_, port = self.address.partition(":")
        return int(port)

    @validator("address", pre=False)
    def _address(cls, v: str):  # noqa
        host, _, port = v.partition(":")
        if not port.strip().isdigit() or int(port) < 1 or int(port) > 65535:
            raise ValueError(f"Bad node address: `{v}`")
        return v

    def __hash__(self) -> int:
        return hash(self.id)

    def __eq__(self, other) -> bool:
        return self.id == other.id

    def __lt__(self, other: "Node") -> bool:
        return self.id.__lt__(other.id)


class ChannelMeta(BaseModel):
    node_id: str = Field(...)
    """node ID"""


class Channel(metaclass=ABCMeta):
    def __init__(self, local_node: Node, target_node: Node):
        """
        :param local_node: current(application) node
        :param target_node: target node
        """
        self.local_node = local_node
        self.target_node = target_node
        self.send_queue: asyncio.Queue["MSG"] = asyncio.Queue()
        """receive queue"""
        self.recv_queue: asyncio.Queue["MSG"] = asyncio.Queue()
        """send queue"""
        self._trigger = asyncio.Event()
        """channel trigger"""

    async def recv(self) -> "MSG":
        """receive a ChannelMSG from channel"""
        return await self.recv_queue.get()

    async def send(self, msg: "MSG") -> None:
        """send a ChannelMSG to channel

        :param msg: ChannelMSG
        """
        await self.send_queue.put(msg)

    @property
    def is_on(self) -> bool:
        """is channel on or not"""
        return self._trigger.is_set()

    async def wait_on(self, timeout: Optional[float] = None) -> None:
        """wait for channel on

        :param timeout: timeout seconds
        """
        await asyncio.wait_for(self._trigger.wait(), timeout)

    @abstractmethod
    def on(self, *_) -> None:
        """open channel"""
        ...

    @abstractmethod
    def off(self) -> None:
        """close channel"""
        ...

    def __hash__(self) -> int:
        return hash(self.local_node.id + self.target_node.id)

    def __eq__(self, other):
        return self.local_node.id == other.local_node.id and self.target_node.id == other.target_node.id

    def __repr__(self) -> str:
        return f'Channel({self.local_node.id} -> {self.target_node.id}, {"ON" if self.is_on else "OFF"})'


class ClientSideChannel(Channel):
    """channel created by client"""

    def on(self) -> None:
        self._trigger.set()

    def off(self) -> None:
        self._trigger.clear()


class ServerSideChannel(Channel):
    """channel created by server"""

    def __init__(self, local_node: Node, target_node: Node) -> None:
        """
        :param local_node: current(application) node
        :param target_node: target node
        """
        self.context: Optional[grpc.ServicerContext] = None
        """GRPC context"""
        super().__init__(local_node, target_node)

    def on(self, context: grpc.ServicerContext) -> None:
        """open channel

        :param context: GRPC context
        """
        self.context = context
        self._trigger.set()

    def off(self) -> None:
        """close channel"""
        self.context = None
        self._trigger.clear()

    @property
    def address(self) -> Optional[str]:
        return self.context.peer() if self.context else None
