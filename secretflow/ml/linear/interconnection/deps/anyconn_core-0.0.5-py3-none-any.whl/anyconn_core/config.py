# Author: Wang Yao <wangyao@tsingj.com>.

import logging
from typing import Dict, List, Union

import yaml
from pydantic import BaseModel, Field, root_validator, validator

from .channel import Node

logger = logging.getLogger("anyconn")

DEFAULT_PACKAGE_SIZE = 3 * 1000 * 1000
"""default package size, 3MB(GRPC limit))"""


class AppConfig(BaseModel):
    node_id: str = Field(..., min_length=1, max_length=255)
    """node ID"""

    debug: bool = Field(False)
    """use debug mode or not"""

    use_admin: bool = Field(False)
    """use admin mode or not"""

    admin_port: int = Field(8000, gt=1, lt=65535)
    """admin port"""

    recv_timeout: float = Field(60)
    """timeout for receiving"""

    send_timeout: float = Field(60)
    """timeout for sending"""

    dispatch_timeout: float = Field(3600)
    """timeout for dispatching"""

    ttl: int = Field(1024)
    """transaction ttl"""

    package_size: int = Field(DEFAULT_PACKAGE_SIZE)
    """package size"""

    nodes: Dict[str, Node] = Field([])
    """all nodes"""

    @validator("nodes", pre=True)
    def __nodes(cls, nodes: List[Union[Dict, Node]]):
        """validate nodes field"""
        if not isinstance(nodes, list):
            nodes = [nodes]

        def _gen():
            for node in nodes:
                if isinstance(node, dict):
                    node: Node = Node.parse_obj(node)
                yield node.id, node

        return _gen()

    @root_validator(pre=False, skip_on_failure=True)
    def _root(cls, values: Dict):
        """check if node_id is in nodes"""
        node_id: str = values["node_id"]
        if node_id not in values["nodes"]:
            raise ValueError(f"Bad application node_id `{node_id}`")
        return values

    @property
    def node(self) -> Node:
        return self.nodes[self.node_id]

    @classmethod
    def parse_yaml(cls, conf_path: str) -> "AppConfig":
        """initialize Config from yaml file

        :param conf_path: yaml file path
        """
        try:
            cfg = yaml.safe_load(open(conf_path, "r"))
        except Exception as e:
            raise ValueError(e) from None
        return cls.parse_obj(cfg)
