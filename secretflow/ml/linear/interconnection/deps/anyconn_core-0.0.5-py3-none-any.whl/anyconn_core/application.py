# Author: Wang Yao <wangyao@tsingj.com>.

"""Application

Application is the core of anyconn. It is responsible for managing channels and transactions.

    - Channel: A channel is a connection between two nodes. It is responsible for sending and receiving messages.
    - Transaction: A transaction is a series of operations between two nodes. It is responsible for sending and receiving messages.
    - Protocol: A protocol is a set of rules for communication between nodes..
"""

import asyncio
import logging
import os
import threading
from asyncio import StreamReader, StreamWriter, start_server as start_http_server
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from itertools import combinations
from typing import Any, Callable, Dict, List, Optional, TypeVar, Union, overload

import grpc
from pydantic import ValidationError
from tiny_listener import Listener
from typing_extensions import final

from .anyconn_pb2_grpc import RouterServicer, add_RouterServicer_to_server
from .channel import (
    Channel,
    ChannelMeta,
    ChannelNotFound,
    ClientSideChannel,
    Node,
    NodeNotFound,
    ServerSideChannel,
)
from .config import AppConfig
from .handler import ChanHandler, HTTPHandler, TransHandler
from .protocol import Error, Package
from .transaction import Transaction

logger = logging.getLogger("anyconn")

Dispatcher = TypeVar("Dispatcher", bound=Callable[[AppConfig, Transaction], Optional[List[Package]]])


class ApplicationNotReady(Exception):
    pass


class Application(Listener):
    def __init__(self) -> None:
        self.channels: Dict[Node, Channel] = {}
        self.process_executor = ProcessPoolExecutor()
        self.thread_executor = ThreadPoolExecutor()
        self.executor = self.thread_executor
        self.dispatch_callback: Optional[Dispatcher] = None
        self.__client_running = threading.Event()
        self.__cfg: Optional[AppConfig] = None
        super().__init__()

    nodes: Dict[str, Node] = property(lambda self: self.__cfg.nodes)
    """all nodes"""
    node: Node = property(lambda self: self.__cfg.node)
    """current node"""
    ttl: int = property(lambda self: self.__cfg.ttl)
    """ttl for transaction"""
    package_size: int = property(lambda self: self.__cfg.package_size)
    """package size, default 3M(GRPC limit)"""
    recv_timeout: float = property(lambda self: self.__cfg.recv_timeout)
    """timeout for recv"""
    dispatch_timeout: float = property(lambda self: self.__cfg.dispatch_timeout)
    """timeout for dispatch"""
    send_timeout: float = property(lambda self: self.__cfg.send_timeout)
    """timeout for send"""
    debug: bool = property(lambda self: self.__cfg.debug)
    """debug mode"""
    admin_port: int = property(lambda self: self.__cfg.admin_port)
    """admin port"""
    user_admin: bool = property(lambda self: self.__cfg.use_admin)
    """use admin or not"""

    @property
    def cfg(self) -> AppConfig:
        return self.__cfg

    @cfg.setter
    def cfg(self, v: Union[AppConfig, str]):
        if isinstance(v, str):
            try:
                self.__cfg = AppConfig.parse_yaml(v)
            except ValidationError as e:
                raise ApplicationNotReady(f"[{self}] Config Initialize Error\n{e}") from e
        else:
            self.__cfg = v

    def dispatch(self, fn: Dispatcher) -> Dispatcher:
        """分发函数装饰器

        :param fn: 分发函数
        """
        self.dispatch_callback = fn
        return fn

    def get_channel(self, node: Union[str, Node]) -> Channel:
        """获取通道

        :param node: 目标节点
        :raises: ChannelNotFound
        """
        try:
            if isinstance(node, str):
                node = self.nodes.get(node)
            return self.channels[node]
        except (NodeNotFound, KeyError) as e:
            raise ChannelNotFound(f"Channel not found: `{node}`") from e

    def get_node(self, node_id: str) -> Node:
        """获取节点

        :param node_id: 节点 ID
        :raises: NodeNotFound
        """
        try:
            return self.nodes[node_id]
        except KeyError as e:
            raise NodeNotFound("Node not found") from e

    async def execute(self, func: Callable, *args: Any) -> Any:
        """执行器中执行"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(self.executor, func, *args)

    # ==================================================
    # run loop
    # ==================================================
    @final
    def _set_client_running(self) -> None:
        """设置客户端状态为运行"""
        self.__client_running.set()

    def wait_client_running(self, timeout: Optional[float] = None) -> bool:
        """等待客户端运行

        :param timeout: 超时时间
        """
        return self.__client_running.wait(timeout)

    @property
    def connect_to(self) -> List[Node]:
        """Override this property, application will auto connect to specified node"""
        return []

    async def http_handler(self, req: StreamReader, resp: StreamWriter) -> None:
        """HTTP connect handler"""
        line: bytes = await req.readline()
        if line:
            method, path, *_ = line.decode().split()
            self.trigger_event(f"/HTTP/{method}{path}", data={"writer": resp})

    @property
    def server_handler(self):
        """GRPC server handler"""
        listener = self

        class Service(RouterServicer):
            async def Main(self, request_iterator, context):
                # bad node metadata
                try:
                    meta: ChannelMeta = ChannelMeta.parse_obj(context.invocation_metadata())
                except ValidationError as e:
                    await context.abort(grpc.StatusCode.INVALID_ARGUMENT, f"Node metadata error: {e}")
                    return

                # 目标节点不存在
                target_node = listener.nodes.get(meta.node_id)
                if target_node is None:
                    await context.abort(
                        grpc.StatusCode.PERMISSION_DENIED,
                        f"Node `{meta.node_id}` is invalid",
                    )

                try:
                    # 创建/恢复通道
                    chan = listener.get_channel(node=target_node)
                except ChannelNotFound:
                    chan = ServerSideChannel(local_node=listener.node, target_node=target_node)
                    listener.channels[target_node] = chan
                    ctx = listener.new_ctx(cid=chan.target_node.id, scope={"chan": chan})
                    ctx.trigger_event("/chan/recv")
                    ctx.trigger_event("/chan/send")
                else:
                    # duplicate channel error
                    if chan.is_on:
                        await context.abort(
                            grpc.StatusCode.ALREADY_EXISTS,
                            f"Node `{meta.node_id}` already exist",
                        )

                # listen channel
                chan.on(context)
                logger.info("[%s] %s", listener, chan)
                try:
                    async for pb_msg in request_iterator:
                        if pb_msg.ttl > listener.ttl:
                            raise ValueError(f"TTL expired [{listener.ttl}]")
                        _type = pb_msg.WhichOneof("payload")
                        if _type == "error":
                            err = Error.parse_pb_MSG(pb_msg)
                            logger.error("[%s] Transaction error [%s]", listener, err)
                        elif _type == "package":
                            await chan.recv_queue.put(Package.parse_pb_MSG(pb_msg))
                except ValidationError as e:
                    await context.abort(grpc.StatusCode.INVALID_ARGUMENT, f"Node package error: {e}")
                chan.off()
                logger.info("[%s] %s", listener, chan)

        return Service()

    async def run_server(self) -> grpc.aio.Server:
        """run node server"""
        grpc_server = grpc.aio.server()
        add_RouterServicer_to_server(self.server_handler, grpc_server)
        grpc_server.add_insecure_port(f"[::]:{self.node.port}")
        await grpc_server.start()
        logger.info("[%s] Started GRPC server: 0.0.0.0:%s", self, self.node.port)
        return grpc_server

    @final
    async def _connect(self, target_node: Node):
        # create channel
        chan = ClientSideChannel(local_node=self.node, target_node=target_node)
        self.channels[target_node] = chan
        # create channel context
        ctx = self.new_ctx(cid=chan.target_node.id, scope={"chan": chan})
        ctx.trigger_event("/chan/recv")
        ctx.trigger_event("/chan/connect")
        await chan.wait_on()

    async def run_client(self) -> None:
        """run node client"""
        # connect to specified node
        for node in set(self.connect_to):
            await self._connect(node)

        # connect to same tag node
        for pairs in combinations((node for node in set(self.nodes.values()) if node.tag == self.node.tag), 2):
            client_node, server_node = sorted(pairs)
            if self.node == client_node:
                await self._connect(server_node)

    @final
    async def _listen(self) -> None:
        # listen HTTP port
        if self.user_admin:
            await start_http_server(self.http_handler, host="0.0.0.0", port=self.admin_port)
            logger.info("[%s] Started HTTP server: 0.0.0.0:%s", self, self.admin_port)

        # listen GRPC port
        server = await self.run_server()
        await self.run_client()
        for chan in self.channels.values():
            await chan.wait_on()
        self._set_client_running()
        await server.wait_for_termination()

    async def listen(self) -> None:
        await self._listen()

    def before_run(self) -> None:
        """run before node startup"""

    @overload
    def run_node(self, cfg: AppConfig) -> None:
        ...

    @overload
    def run_node(self, conf_path: str) -> None:
        ...

    def run_node(self, cfg: Union[AppConfig, str]) -> None:
        self.cfg = cfg
        logger.setLevel(logging.DEBUG if self.debug else logging.INFO)

        # handler
        ChanHandler(self).install()
        TransHandler(self).install()
        if self.user_admin:
            HTTPHandler(self).install()

        self.before_run()
        # run loop
        self.run()
        logger.info(
            "[%s] Started Anyconn-Router process[%s] (Press CTRL+C to quit)",
            self,
            os.getpid(),
        )

    def stop(self) -> None:
        self.process_executor.shutdown(wait=False)
        self.thread_executor.shutdown(wait=False)
        logger.info("[%s] Finished Anyconn-Router process[%s]", self, os.getpid())

    def __repr__(self) -> str:
        return f"Node[{self.node.id if self.cfg else None}]"
