import click
from anyconn_core import AppConfig

from router import RC, RS, __version__


def show_version(ctx, _, value) -> None:
    if not value or ctx.resilient_parsing:
        return
    click.echo(f"anyconn {__version__}")
    ctx.exit()


@click.command(help="run node")
@click.option(
    "--version", is_flag=True, callback=show_version, expose_value=False, is_eager=True, help="Display version info."
)
@click.option("--conf-path", "-c", required=True, help="path of configuration file(.yaml)")
def main(conf_path: str):
    cfg = AppConfig.parse_yaml(conf_path)
    app = RC() if cfg.node.tag == "RC" else RS()
    app.run_node(cfg)


if __name__ == "__main__":
    main()
