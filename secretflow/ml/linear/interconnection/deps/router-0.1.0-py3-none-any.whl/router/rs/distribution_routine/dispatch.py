from typing import List

from router.utils import Pack

from .convertor import HE_2_SS, RS_SS2_2_RC_HE


class RSDispatchError(Exception):
    pass


def dispatch(packs: List[Pack]):
    pack = packs[0]
    if pack.process == "he2ss":
        return HE_2_SS.trans(pack)

    if pack.process == "ss2he":
        # rs1 recv packs: [pack_from_rc1, pack_from_rc3]
        # rs2 recv packs: [pack_from_rc2, pack_from_rs1]
        if packs[0].encryption != "ss":
            packs[0], packs[1] = packs[1], packs[0]

        # rs1 case: packs: [pack_from_rc1, pack_from_rc3]
        if packs[1].source_id.lower().startswith("rc"):  # todo refactor: use node_type
            return RS_SS2_2_RC_HE.return_pub_from_rs(packs)
        # rs2 case: packs: [pack_from_rc2, pack_from_rs1]
        if packs[1].source_id.lower().startswith("rs"):  # todo refactor: use node_type
            return RS_SS2_2_RC_HE.rs_2_rs(packs)

        raise RSDispatchError("Invalid source_id, should be 'rc' or 'rs")

    raise RSDispatchError(f"Invalid process name, should be 'ss2he' or 'he2ss, not {pack.process}")
