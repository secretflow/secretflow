from heu import phe

from typing import List
import pickle

from router.utils import Pack


class RS_SS2_2_RC_HE:
    @staticmethod
    def return_pub_from_rs(packs: List[Pack]):
        """
        rs1 case: packs: [pack_from_rc1, pack_from_rc3]
        Step 4, receive pub from rc and send the encrypted x1 and pub to rs2
        """
        pack_from_rc1 = packs[0]  # share x1 pack
        pack_from_rc3 = packs[1]  # public_key pack
        kit = phe.setup(pickle.loads(pack_from_rc3.key.encode("latin1")))
        ct_buffer_list = [pickle.dumps(kit.encryptor().encrypt_raw(ct_buffer)).decode("latin1")
                          for ct_buffer in pack_from_rc1.data]
        return [
            pack_from_rc3.like(
                source_id=pack_from_rc3.target_id,
                target_id=pack_from_rc3.router_table[pack_from_rc3.target_id]["rs"][0],
                data=ct_buffer_list,
                dtype="int",
                n_batches=2,
                uid=pack_from_rc3.uid,
            )
        ]

    @staticmethod
    def rs_2_rs(packs: List[Pack]):
        """
        rs2 case: packs: [pack_from_rc2, pack_from_rs1]
        """
        pack_from_rc2 = packs[0]
        pack_from_rs1 = packs[1]  # which has public_key
        public_key = pickle.loads(pack_from_rs1.key.encode("latin1"))
        kit = phe.setup(public_key)
        rc1_ct = [pickle.loads(ct_buffer.encode("latin1")) for ct_buffer in pack_from_rs1.data]
        rc2_ct = [kit.encryptor().encrypt_raw(x) for x in pack_from_rc2.data]

        sum_ct = [kit.evaluator().add(i, j) for i, j in zip(rc1_ct, rc2_ct)]
        sum_ct_buffer = [pickle.dumps(ct).decode("latin1") for ct in sum_ct]

        return [
            pack_from_rs1.like(
                source_id=pack_from_rs1.target_id,
                target_id=pack_from_rs1.router_table[pack_from_rs1.target_id]["rc"][1],
                data=sum_ct_buffer,
                dtype="int",
                n_batches=1,
                uid=pack_from_rs1.uid,
            )
        ]


class HE_2_SS:
    @staticmethod
    def trans(pack: Pack):
        return [pack.like(source_id=pack.target_id, target_id=pack.router_table[pack.target_id]["rc"][0])]
