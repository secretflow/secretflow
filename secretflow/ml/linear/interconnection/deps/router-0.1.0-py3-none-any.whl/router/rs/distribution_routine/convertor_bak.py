from typing import List

import numpy as np
from phe import paillier

from router.utils import Pack


class RS_SS2_2_RC_HE:
    @staticmethod
    def return_pub_from_rs(packs: List[Pack]):
        """
        Step 4, receive pub from rc and send the encrypted x1 and pub to rs2
        """
        pack = packs[1]
        data_on_rs1 = packs[0].data
        transed_key = np.array(pack.key).astype(np.uint8).tobytes()
        n = int.from_bytes(transed_key, "big")
        p1 = paillier.PaillierPublicKey(n)
        return [
            pack.like(
                source_id=pack.target_id,
                target_id=pack.router_table[pack.target_id]["rs"][0],
                data=[p1.encrypt(i) for i in data_on_rs1],
                dtype="int",
                n_batches=2,
                uid=pack.uid,
            )
        ]

    @staticmethod
    def rs_2_rs(packs: List[Pack]):
        pack = packs[1]
        data_on_rs2 = packs[0].data
        transed_key = np.array(pack.key).astype(np.uint8).tobytes()

        # ==================================================
        # todo fix: p1 assigned but never used
        n = int.from_bytes(transed_key, "big")
        p1 = paillier.PaillierPublicKey(n)  # noqa: F841
        # ==================================================

        encrypted = [i + j for i, j in zip(list(pack.data), list(data_on_rs2))]
        return [
            pack.like(
                source_id=pack.target_id,
                target_id=pack.router_table[pack.target_id]["rc"][1],
                data=encrypted,
                dtype="int",
                n_batches=1,
                uid=pack.uid,
            )
        ]


class HE_2_SS:
    @staticmethod
    def trans(pack: Pack):
        return [pack.like(source_id=pack.target_id, target_id=pack.router_table[pack.target_id]["rc"][0])]
