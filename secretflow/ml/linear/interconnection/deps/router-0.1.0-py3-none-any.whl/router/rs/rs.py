from traceback import print_exc
from typing import List

from anyconn_core import AppConfig, Application, Package as anyconn_Package, Transaction

from router.utils import Pack

from .distribution_routine import RSDispatchError, dispatch


class RS(Application):
    def __init__(self) -> None:
        super().__init__()

        @self.dispatch
        def my_dispatcher(cfg: AppConfig, trans: Transaction) -> List[anyconn_Package]:
            def _make():
                try:
                    for pack in dispatch(Pack.parse_Transaction(trans)):
                        yield from pack.packages_generator(cfg.package_size)
                except RSDispatchError:
                    print_exc()  # todo
                except Exception:
                    print_exc()  # todo

            return list(_make())
