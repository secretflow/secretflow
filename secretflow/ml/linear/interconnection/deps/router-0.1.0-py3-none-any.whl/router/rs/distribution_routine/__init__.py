from .dispatch import RSDispatchError, dispatch

__all__ = ["dispatch", "RSDispatchError"]
