import asyncio
import logging
import threading
import time
from contextlib import contextmanager
from functools import partial
from queue import Queue
from typing import Callable, ContextManager, List, Optional, Tuple, Union

from anyconn_core import (
    AppConfig,
    Application,
    ChannelNotFound,
    Node,
    Transaction,
    TransactionStage,
    scope,
)
from tiny_listener import Depends, Event

from router.utils import Pack

logger = logging.getLogger("anyconn")

OnRecvCallback = Callable[[Transaction], None]


class RCError(Exception):
    pass


class RC(Application):
    def __init__(self):
        super().__init__()
        self.executor = self.thread_executor
        self.on_recv_callback: List[OnRecvCallback] = []
        self.q_recv: Queue = Queue()
        self.on_recv_callback.append(lambda trans: self.q_recv.put(trans))
        self.loop = asyncio.new_event_loop()

        @self.dispatch
        def my_dispatcher(_: AppConfig, trans: Transaction) -> None:
            [on_recv(trans) for on_recv in self.on_recv_callback]

        @self.on_event("/trans/go")
        async def trans_go(event: Event, trans: Transaction = Depends(scope("trans"))):
            app: RC = event.listener  # noqa
            logger.debug("[%s] Transaction(cid=%s, PREPARING)", app, event.ctx.cid)
            # 开始事务计时
            trans.set_stage(TransactionStage.DISPATCHING)
            trans.set_stage(TransactionStage.SENDING)
            event.ctx.trigger_event("/trans/timer")
            trans.rest = sum(len(op.packages) for op in trans.ops.values())
            for node_id, op in trans.ops.items():
                chan = app.get_channel(node_id)
                [await chan.send(pack) for pack in op.packages]

    def wait_client_running(self, timeout: float = 60) -> None:
        du = 0.2
        timeout_val = timeout
        while timeout > 0:
            if len(self.channels) >= 2:
                return
            time.sleep(du)
            timeout -= du

        raise TimeoutError(f"wait_client_running timeout {timeout_val} s")

    @property
    def connect_to(self) -> List[Node]:
        """连接目标节点(所有类型为 RS 的节点)"""
        return [node for node in self.nodes.values() if node.tag == "RS"]

    def recv(self, block: bool = True, timeout: Optional[float] = None) -> List[Pack]:
        """接收 Pack

        :param block: 是否阻塞
        :param timeout: 超时时间
        """
        return Pack.parse_Transaction(self.q_recv.get(block, timeout))

    def send(self, *packs: Pack, block: bool = True, timeout: Optional[float] = None) -> None:
        """发送 Pack

        :param packs: 待发送 Pack
        :param block: 是否阻塞
        :param timeout: 超时时间
        """
        if not self.loop.is_running():
            raise RCError("Send fail: App is not running")

        trans = Transaction(deadline=self.recv_timeout)
        for pack in packs:
            try:
                node = self.nodes.get(pack.target_id)
                while node not in self.channels:
                    time.sleep(1)
                    logger.info(f"wait for connection {node}")
                self.get_channel(pack.target_id)
            except ChannelNotFound as e:
                raise RCError(e) from e
            for anyconn_pack in pack.packages_generator(self.package_size, auto_cid=False):
                trans.commit(anyconn_pack)

        ctx = self.new_ctx(trans.cid, scope={"trans": trans})
        self.loop.call_soon_threadsafe(partial(ctx.trigger_event, timeout=None, data=None), "/trans/go")
        while self.ctxs.get(ctx.cid):
            time.sleep(1)

    def _thread(self, cfg: Union[AppConfig, str]) -> threading.Thread:
        self.executor = self.thread_executor

        def run():
            self.run_node(cfg)

        return threading.Thread(target=run)

    @contextmanager
    def run_in_thread(self, cfg: Union[AppConfig, str], timeout: float = 180) -> ContextManager[Tuple[threading.Thread, Callable, Callable]]:
        """在线程执行"""
        t = self._thread(cfg)
        t.start()
        self.wait_client_running(timeout=timeout)
        yield t, self.send, self.recv

    def run_in_thread_forever(self, cfg: Union[AppConfig, str], timeout: float = 180) -> threading.Thread:
        """线程启动客户端"""
        t = self._thread(cfg)
        t.start()
        self.wait_client_running(timeout=timeout)
        return t

    def setup_event_loop(self) -> asyncio.AbstractEventLoop:
        if not self.is_main_thread():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        self.loop = asyncio.get_event_loop()
        return self.loop
