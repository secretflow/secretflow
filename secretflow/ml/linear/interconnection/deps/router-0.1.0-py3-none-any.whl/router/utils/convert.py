from typing import List

import numpy as np


def int2list(n, length=256) -> List[int]:
    """Convert a big int to a list of uint8
    todo fix: deal with OverflowError
    todo fix: deal with negative number

    parameters
    -----------
    n : int
        PaillierPublicKey.n

    length : int
        The parameter of  int.to_bytes().

    Returns
    --------
    res : list of int
    """
    n = n.to_bytes(length, "big")
    return [int(i) for i in np.frombuffer(n, dtype=np.uint8)]


def list2int(key_list) -> int:
    """convert a list of uint8 to big int.

    Parameters
    ----------
    key_list : list of uint8

    Returns
    -------
    res : int
    """
    n = np.array(key_list).astype(np.uint8).tobytes()
    return int.from_bytes(n, "big")
