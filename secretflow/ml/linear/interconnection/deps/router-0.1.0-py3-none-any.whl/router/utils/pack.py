import math
import pickle
from typing import Any, Callable, Dict, Generator, List, Union

from anyconn_core import Package as anyconn_Package, Transaction


class Pack:
    """

    Parameters
    ----------
    task_id : str

    source_id : str
        The id of source RC or RS.

    data_id : str

    target_id : str
        The id of target RC or RS.

    encryption : str, default is None.
        The encryption type.  {'ss', 'he'}.

    shape : tuple of int.
        Shape of data.

    dtype : int
        Type of data. {"int"}.

    data : list.

    process : str.
        The process of data transform.{'ss2he', 'he2ss'}.

    key : str.
        The public key of homomorphic encryption.

    n_batches : int
        The data may be sent unpacked. This parameter is the number of packets.

    uid : str or int

    router_table : dict.
    """

    def __init__(
        self,
        task_id: Union[str, None] = None,  # todo fix: int or str ?
        source_id: Union[str, None] = None,
        data_id: Union[str, None] = None,  # todo fix: int or str ?
        target_id: Union[str, None] = None,
        encryption: Union[str, None] = None,
        shape: Union[tuple, None] = None,
        dtype: Union[str, None] = None,  # todo fix: int or str ?
        data: Union[List, None] = None,
        process: Union[str, None] = None,
        key: Union[str, None] = None,
        n_batches: Union[int, None] = None,
        uid: Union[str, int, None] = None,
        router_table: Union[Dict, None] = None,
    ):
        # 转发信息
        self.uid = uid  # -> cid
        self.target_id = target_id  # next_node
        self.n_batches = n_batches  # -> operation
        self.data = data
        # 其他自描述信息
        self.task_id = task_id
        self.source_id = source_id
        self.data_id = data_id
        self.encryption = encryption
        self.shape = shape
        self.dtype = dtype
        self.process = process
        self.key = key
        self.router_table = router_table

    # ============================================================
    # 以下为适配隐私路由必要的代码
    # ============================================================
    detail: Dict[str, Any] = property(
        lambda self: {
            "task_id": self.task_id,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "data_id": self.data_id,
            "encryption": self.encryption,
            "shape": list(self.shape),
            "dtype": self.dtype,
            "process": self.process,
            "key": self.key,
            "router_table": self.router_table,
        }
    )

    def __str__(self) -> str:
        return f"""Pack(
task_id: {self.task_id},
source_id: {self.source_id},
data_id: {self.data_id},
target_id: {self.target_id},
encryption: {self.encryption},
shape: {self.shape},
dtype: {self.dtype},
data: {self.data},
process: {self.process},
key: {self.key},
n_batches: {self.n_batches},
uid: {self.uid},
router_table: {self.router_table}
)"""

    def like(
        self,
        task_id=None,
        source_id=None,
        data_id=None,
        target_id=None,
        encryption=None,
        shape=None,
        dtype=None,
        data=None,
        process=None,
        key=None,
        n_batches=None,
        uid=None,
        router_table=None,
    ):
        task_id = task_id if task_id else self.task_id
        source_id = source_id if source_id else self.source_id
        data_id = data_id if data_id else self.data_id
        target_id = target_id if target_id else self.target_id
        encryption = encryption if encryption else self.encryption
        shape = shape if shape else self.shape
        dtype = dtype if dtype else self.dtype
        data = data if data is not None else self.data
        process = process if process else self.process
        key = key if key else self.key
        n_batches = n_batches if n_batches else self.n_batches
        uid = uid if uid else self.uid
        router_table = router_table if router_table else self.router_table
        new_pack = Pack(
            task_id=task_id,
            source_id=source_id,
            data_id=data_id,
            target_id=target_id,
            encryption=encryption,
            shape=shape,
            dtype=dtype,
            data=data,
            process=process,
            key=key,
            n_batches=n_batches,
            uid=uid,
            router_table=router_table,
        )
        return new_pack

    @property
    def packages_generator(
        self,
    ) -> Callable[[int], Generator[anyconn_Package, None, None]]:
        """anyconn_Package 生成器"""

        def _gen(package_size: int, auto_cid: bool = True):
            cid = f"_{self.uid}" if auto_cid else self.uid
            tmp = pickle.dumps(self.data)
            total = math.ceil(len(tmp) / package_size)
            for i in range(total):
                yield anyconn_Package(
                    cid=cid,
                    operation=self.n_batches,
                    seq=i + 1,
                    total=total,
                    node_id=self.target_id,
                    detail=self.detail,
                    data=tmp[i * package_size : (i + 1) * package_size],
                )

        return _gen

    @classmethod
    def parse_Transaction(cls, trans: Transaction) -> List["Pack"]:
        """通过事务初始化"""
        trans_back = []
        for node_id, op in trans.ops.items():
            pack = cls(uid=trans.cid, n_batches=trans.op_count, data=pickle.loads(op.data()), **op.detail)
            pack.shape = tuple(pack.shape)
            trans_back.append(pack)

        return trans_back
