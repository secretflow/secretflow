from anyconn_core import AppConfig
from router import RC
import pickle
import logging
from heu import phe

logger = logging.getLogger("anyconn")

router_table = {
    "rs_01": {"rs": ["rs_02"], "rc": ["rc_01", "rc_03"]},
    "rs_02": {"rs": ["rs_01"], "rc": ["rc_02", "rc_04"]},
}

nodes = [
    {"id": "rs_01", "tag": "RS", "address": "localhost:50051"},
    {"id": "rs_02", "tag": "RS", "address": "localhost:50052"},
    {"id": "rc_01", "tag": "RC01", "address": "localhost:50061"},
    {"id": "rc_02", "tag": "RC02", "address": "localhost:50062"},
    {"id": "rc_03", "tag": "RC03", "address": "localhost:50063"},
    {"id": "rc_04", "tag": "RC04", "address": "localhost:50064"},
]


def run_rc_04():
    client_he = phe.setup(phe.SchemaType.ZPaillier, 2048)
    print("public_key:", client_he.public_key())

    with open("public_key", 'wb') as f:
        pickle.dump(client_he.public_key(), f)

    rc = RC()
    with rc.run_in_thread(AppConfig(node_id="rc_04", nodes=nodes)):
        result = []
        for pack in rc.recv():
            res = [client_he.decryptor().decrypt_raw(pickle.loads(ct_buffer.encode("latin1"))) for ct_buffer in
                   pack.data]
            result.extend(res)
        result = [data / 2**40 for data in result]
        logger.info(f"rc_04 recv: {result}")


if __name__ == "__main__":
    run_rc_04()
