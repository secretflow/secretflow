1. 同时运行`he2ss`里的5个python代码（同态加密到秘密共享的转换），可以运行看到he_rc_03.py和he_rc_04.py发送同态数据给ss_rc_01.py和ss_rc_02.py ![demo_he2ss](img/demo_he2ss.jpeg)
2. 同时运行`ss2he`里的python代码（秘密共享到同态加密的转换），可以运行看到he_rc_03.py和he_rc_04.py发送同态数据给ss_rc_01.py和ss_rc_02.py ![demo_ss2he](img/demo_ss2he.png)
3. `horizontal_lr`展示了privpy和隐语横向LR代码互联互通的样例程序![privpy-隐语互联互通-横向lr](img/privpy-隐语互联互通-横向lr.jpg)

样例为在Privpy进行两边lr权重的聚合工作，聚合成功后，privpy使用聚合后参数进行下一轮迭代，secretflow收到privpy传回来的聚合后参数进行下一轮迭代。

## 本地模拟

> 安装`router-0.1.0-py3-none-any.whl`和`anyconn_core-0.0.5-py3-none-any.whl`（文件位于deps目录下）

在这个样例中只有3个RC。

模拟代码为`ss_rc_01.py`,`ss_rc_02.py`,`he_rc_03.py`,`rs.py`四个代码文件。

在调试阶段，可以用`ss_rc_01.py`,`ss_rc_02.py`,`rs.py`三个文件模拟privpy侧行为，和secretflow进行联调

在调试阶段，可以用`he_rc_03.py`文件模拟secretflow侧行为，和privpy进行联调

## 集群测试

### Secretflow侧配置

`router_hooks.py`是位于`secretflow/ml/linear/interconnection/router_hooks.py`下的文件。

> 需要在Secretflow侧安装router-0.1.0-py3-none-any.whl和anyconn_core-0.0.5-py3-none-any.whl

### 运行secretflow
在项目根目录下运行：
`pytest tests/ml/linear/test_fl_lr_mix.py  --env=prod -v --capture=no`